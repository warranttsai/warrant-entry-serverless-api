# warrant-entry-serverless-api
This is the serverless API with AWS Lambda
