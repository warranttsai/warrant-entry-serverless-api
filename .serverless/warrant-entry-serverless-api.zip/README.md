# warrant-entry-serverless-api
This is the serverless API with AWS Lambda and DynamoDB

APIs:
- comment
- comments

Runtime: nodejs14.x
plugins:
  - serverless-offline